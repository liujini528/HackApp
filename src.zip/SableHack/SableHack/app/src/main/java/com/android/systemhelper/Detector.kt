package com.android.systemhelper

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import java.util.concurrent.Executors

object Detector {
    data class Target(val x: Int, val y: Int, val w: Int, val h: Int, val health: Int)
    @Volatile var latest: List<Target> = emptyList()
    private val executor = Executors.newSingleThreadExecutor()
    private var busy = false
    private const val SCALE = 0.4f

    fun submit(bmp: Bitmap) {
        if (busy) return
        busy = true
        executor.execute {
            val sw = (bmp.width * SCALE).toInt()
            val sh = (bmp.height * SCALE).toInt()
            val scaledBmp = Bitmap.createScaledBitmap(bmp, sw, sh, false)
            val rgba = Mat(); Utils.bitmapToMat(scaledBmp, rgba)
            val hsv = Mat(); Imgproc.cvtColor(rgba, hsv, Imgproc.COLOR_RGBA2HSV)
            
            val maskBody = Mat()
            Core.inRange(hsv, Scalar(0.0, 0.0, 0.0), Scalar(180.0, 255.0, 80.0), maskBody)
            
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(maskBody, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            
            val out = ArrayList<Target>()
            for (c in contours) {
                val r = Imgproc.boundingRect(c)
                val ar = r.width.toFloat() / r.height.toFloat()
                if (ar < 0.25f || ar > 1.2f) continue
                if (r.width < 15 * SCALE || r.height < 30 * SCALE) continue
                if (r.y < sh * 0.3f) continue
                
                out.add(Target((r.x / SCALE).toInt(), (r.y / SCALE).toInt(), (r.width / SCALE).toInt(), (r.height / SCALE).toInt(), 100))
            }
            latest = out
            busy = false
        }
    }
}